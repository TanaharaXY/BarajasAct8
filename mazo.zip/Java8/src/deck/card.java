package deck;

import java.util.ArrayList;

/**
 *
 * @author Intel
 */
public class card {
    ArrayList<String> deck = new ArrayList<String>();
        String[] palo = { "Tréboles", "Corazones", "Picas", "Diamantes" };
        String[] color = { "Rojo", "Negro" };
        String[] valor = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "A", "J", "Q", "K" };
}
